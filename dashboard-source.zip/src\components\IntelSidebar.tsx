import AlertFeed from './AlertFeed';
import DisasterWidget from './DisasterWidget';
import EconomyWidget from './EconomyWidget';
import HealthWidget from './HealthWidget';
import NewsWidget from './NewsWidget';
import type { GeoEvent, Traveler } from '../types';

interface IntelSidebarProps {
  events: GeoEvent[];
  travelers: Traveler[];
  selectedEvent: GeoEvent | null;
  onSelectEvent: (e: GeoEvent) => void;
}

export default function IntelSidebar({ events, travelers, selectedEvent, onSelectEvent }: IntelSidebarProps) {
  return (
    <div className="intel-sidebar">
      <DisasterWidget events={events} travelers={travelers} selectedEvent={selectedEvent} onSelectEvent={onSelectEvent} />
      <AlertFeed events={events} selectedEvent={selectedEvent} onSelectEvent={onSelectEvent} />
      <EconomyWidget />
      <HealthWidget />
      <NewsWidget />
    </div>
  );
}
