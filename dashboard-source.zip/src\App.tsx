import { useState, useEffect, useCallback, useRef } from 'react';
import Header from './components/Header';
import StatsBar from './components/StatsBar';
import WorldMap from './components/WorldMap';
import IntelSidebar from './components/IntelSidebar';
import TravelerPanel from './components/TravelerPanel';
import EventDetail from './components/EventDetail';
import NotificationToast from './components/NotificationToast';
import RegisterModal from './components/RegisterModal';
import CommitteePanel from './components/CommitteePanel';
import CommitteeView from './components/CommitteeView';
import { loadFirebaseConfig, initFirebase } from './services/firebaseRt';
import { fetchGDACSEvents } from './services/gdacs';
import { fetchUSGSEarthquakes } from './services/usgs';
import { fetchExtraDisasterEvents } from './services/disasters';
import { MOCK_EVENTS, MOCK_TRAVELERS } from './services/mockData';
import { generateNotificationMessage, generateNotificationMessageAr, generateAiSuggestion, generateActionSteps } from './services/riskEngine';
import { registerServiceWorker, requestPermission, sendPushNotification, onAcknowledge } from './services/pushNotification';
import type { GeoEvent, Traveler, Notification, DashboardStats } from './types';
import './index.css';

// If URL has ?view=committee, show the committee view instead of dashboard
const IS_COMMITTEE_VIEW = new URLSearchParams(window.location.search).get('view') === 'committee';

// Init Firebase on load if already configured (needed for committee view)
const savedFbCfg = loadFirebaseConfig();
if (savedFbCfg) initFirebase(savedFbCfg);

function loadSavedTraveler(): Traveler | null {
  try {
    const raw = localStorage.getItem('my-traveler');
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return {
      ...parsed,
      arrivalDate: new Date(parsed.arrivalDate),
      departureDate: new Date(parsed.departureDate),
    };
  } catch {
    return null;
  }
}

export default function App() {
  if (IS_COMMITTEE_VIEW) return <CommitteeView />;

  const [events, setEvents] = useState<GeoEvent[]>([]);
  const [travelers, setTravelers] = useState<Traveler[]>(() => {
    const saved = loadSavedTraveler();
    return saved ? [saved, ...MOCK_TRAVELERS] : MOCK_TRAVELERS;
  });
  const [selectedEvent, setSelectedEvent] = useState<GeoEvent | null>(null);
  const [selectedTraveler, setSelectedTraveler] = useState<Traveler | null>(null);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [loading, setLoading] = useState(true);
  const [pushEnabled, setPushEnabled] = useState(false);
  const [showRegister, setShowRegister] = useState(false);
  const autoAlertedRef = useRef(new Set<string>());

  // Register service worker on load
  useEffect(() => {
    registerServiceWorker().then(async (reg) => {
      if (!reg) return;
      const granted = await requestPermission();
      setPushEnabled(granted);
      onAcknowledge((travelerId, eventId) => {
        setNotifications((prev) =>
          prev.map((n) =>
            n.travelerId === travelerId && n.eventId === eventId
              ? { ...n, sent: false }
              : n
          )
        );
      });
    });
  }, []);

  // Auto-alert MY device when a CRITICAL/HIGH event matches my country
  useEffect(() => {
    const myDevice = travelers.find((t) => t.id.startsWith('my-device'));
    if (!myDevice || !pushEnabled) return;

    const matching = events.filter(
      (e) =>
        e.countryCode === myDevice.countryCode &&
        (e.riskLevel === 'CRITICAL' || e.riskLevel === 'HIGH')
    );

    matching.forEach((event) => {
      const key = `${myDevice.id}-${event.id}`;
      if (autoAlertedRef.current.has(key)) return;
      autoAlertedRef.current.add(key);

      const aiSug = generateAiSuggestion(event, myDevice);
      const steps = generateActionSteps(event);
      const notif: Notification = {
        id: `auto-${myDevice.id}-${event.id}`,
        travelerId: myDevice.id,
        travelerName: myDevice.nameEn,
        eventId: event.id,
        eventTitle: event.title,
        riskLevel: event.riskLevel,
        message: generateNotificationMessage(event, myDevice),
        messageAr: generateNotificationMessageAr(event, myDevice),
        aiSuggestion: aiSug.en,
        aiSuggestionAr: aiSug.ar,
        actionSteps: steps.en,
        actionStepsAr: steps.ar,
        timestamp: new Date(),
        sent: true,
      };
      setNotifications((prev) => [notif, ...prev]);
      sendPushNotification(event, myDevice);
    });
  }, [events, travelers, pushEnabled]);

  useEffect(() => {
    async function loadLiveData() {
      setLoading(true);
      try {
        const [gdacs, usgs, extraDisasters] = await Promise.allSettled([
          fetchGDACSEvents(),
          fetchUSGSEarthquakes(),
          fetchExtraDisasterEvents(),
        ]);
        const live: GeoEvent[] = [
          ...MOCK_EVENTS,
          ...(gdacs.status === 'fulfilled' ? gdacs.value : []),
          ...(usgs.status === 'fulfilled' ? usgs.value : []),
          ...(extraDisasters.status === 'fulfilled' ? extraDisasters.value : []),
        ];
        setEvents(live);
        setLastUpdated(new Date());
      } catch {
        // API fetch failed
      } finally {
        setLoading(false);
      }
    }
    loadLiveData();
    const interval = setInterval(loadLiveData, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const handleRegister = useCallback((traveler: Traveler) => {
    setTravelers((prev) => {
      const without = prev.filter((t) => !t.id.startsWith('my-device'));
      return [traveler, ...without];
    });
    setPushEnabled(true);
  }, []);

  const dismissNotification = useCallback((id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  }, []);

  const sendAlert = useCallback(async (travelerId: string) => {
    const traveler = travelers.find((t) => t.id === travelerId);
    if (!traveler) return;

    // Use the selected event, fall back to the traveler's first alert event, then the most critical event
    const event =
      selectedEvent ??
      (traveler.alerts.length > 0 ? events.find((e) => e.id === traveler.alerts[0]) : null) ??
      [...events].sort((a, b) => {
        const p: Record<string, number> = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3, SAFE: 4 };
        return (p[a.riskLevel] ?? 5) - (p[b.riskLevel] ?? 5);
      })[0];

    if (!event) return;

    const aiSug = generateAiSuggestion(event, traveler);
    const steps = generateActionSteps(event);
    const notif: Notification = {
      id: `notif-${travelerId}-${event.id}-${Date.now()}`,
      travelerId,
      travelerName: traveler.nameEn,
      eventId: event.id,
      eventTitle: event.title,
      riskLevel: event.riskLevel,
      message: generateNotificationMessage(event, traveler),
      messageAr: generateNotificationMessageAr(event, traveler),
      aiSuggestion: aiSug.en,
      aiSuggestionAr: aiSug.ar,
      actionSteps: steps.en,
      actionStepsAr: steps.ar,
      timestamp: new Date(),
      sent: true,
    };

    setNotifications((prev) => [notif, ...prev]);
    if (pushEnabled) await sendPushNotification(event, traveler);
  }, [selectedEvent, travelers, events, pushEnabled]);

  const stats: DashboardStats = {
    totalEvents: events.length,
    criticalEvents: events.filter((e) => e.riskLevel === 'CRITICAL').length,
    affectedCountries: new Set(events.map((e) => e.countryCode).filter(Boolean)).size,
    travelersAtRisk: travelers.filter((t) => t.status === 'ALERTED' || t.status === 'EVACUATED').length,
    notificationsSent: notifications.filter((n) => n.sent).length,
    activeAlerts: events.filter((e) => e.riskLevel === 'CRITICAL' || e.riskLevel === 'HIGH').length,
  };

  const travelersAtRiskForEvent = selectedEvent
    ? travelers.filter((t) => t.countryCode === selectedEvent.countryCode).length
    : 0;

  return (
    <div className="app">
      <Header
        notificationCount={notifications.length}
        lastUpdated={lastUpdated}
        pushEnabled={pushEnabled}
        onEnablePush={async () => {
          const granted = await requestPermission();
          setPushEnabled(granted);
        }}
      />
      <StatsBar stats={stats} />

      {loading && (
        <div className="loading-bar">
          <div className="loading-fill" />
        </div>
      )}

      <main className="main-grid">
        <IntelSidebar
          events={events}
          travelers={travelers}
          selectedEvent={selectedEvent}
          onSelectEvent={setSelectedEvent}
        />

        <div className="map-section">
          <WorldMap
            events={events}
            travelers={travelers}
            selectedEvent={selectedEvent}
            onSelectEvent={setSelectedEvent}
            selectedTraveler={selectedTraveler}
          />
          {selectedEvent && (
            <EventDetail
              event={selectedEvent}
              travelersAtRisk={travelersAtRiskForEvent}
              onClose={() => setSelectedEvent(null)}
            />
          )}
        </div>

        <div className="right-column">
          <TravelerPanel
            travelers={travelers}
            events={events}
            onSendAlert={sendAlert}
            onRegisterClick={() => setShowRegister(true)}
            onSelectTraveler={setSelectedTraveler}
          />
          <CommitteePanel
            selectedEvent={selectedEvent}
            travelersAtRisk={travelersAtRiskForEvent}
          />
        </div>
      </main>

      <NotificationToast notifications={notifications} onDismiss={dismissNotification} />

      {showRegister && (
        <RegisterModal
          onRegister={handleRegister}
          onClose={() => setShowRegister(false)}
        />
      )}
    </div>
  );
}
