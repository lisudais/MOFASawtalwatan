import type { CommodityQuote, PricePoint } from '../types';

const SYMBOLS: { symbol: string; nameEn: string; nameAr: string }[] = [
  { symbol: 'XAU/USD', nameEn: 'Gold',   nameAr: 'الذهب' },
  { symbol: 'XAG/USD', nameEn: 'Silver', nameAr: 'الفضة' },
  { symbol: 'WTI/USD', nameEn: 'Crude Oil (WTI)', nameAr: 'النفط (WTI)' },
  { symbol: 'BRENT/USD', nameEn: 'Crude Oil (Brent)', nameAr: 'النفط (برنت)' },
];

export async function fetchCommodityPrices(): Promise<CommodityQuote[]> {
  const apiKey = import.meta.env.VITE_TWELVEDATA_API_KEY;
  if (!apiKey) return [];

  try {
    const url = `https://api.twelvedata.com/quote?symbol=${SYMBOLS.map((s) => s.symbol).join(',')}&apikey=${apiKey}`;
    const res = await fetch(url, { signal: AbortSignal.timeout(8000) });
    const data = await res.json();

    return SYMBOLS.map(({ symbol, nameEn, nameAr }) => {
      const quote = data[symbol] ?? (data.symbol === symbol ? data : null);
      if (!quote || quote.code || quote.status === 'error') return null;

      const price = parseFloat(quote.close);
      const changePercent = parseFloat(quote.percent_change);
      if (Number.isNaN(price)) return null;

      return {
        symbol,
        nameEn,
        nameAr,
        price,
        changePercent: Number.isNaN(changePercent) ? 0 : changePercent,
        currency: quote.currency_quote ?? 'USD',
      } as CommodityQuote;
    }).filter(Boolean) as CommodityQuote[];
  } catch {
    return [];
  }
}

async function fetchTimeSeries(symbol: string, apiKey: string): Promise<PricePoint[]> {
  const url = `https://api.twelvedata.com/time_series?symbol=${symbol}&interval=1day&outputsize=14&apikey=${apiKey}`;
  const res = await fetch(url, { signal: AbortSignal.timeout(8000) });
  const data = await res.json();
  if (data.status === 'error' || !Array.isArray(data.values)) return [];

  return (data.values as any[])
    .map((v) => ({ date: new Date(v.datetime), value: parseFloat(v.close) }))
    .filter((p) => !Number.isNaN(p.value))
    .reverse();
}

export async function fetchCommodityTrends(): Promise<{ gold: PricePoint[]; oil: PricePoint[] }> {
  const apiKey = import.meta.env.VITE_TWELVEDATA_API_KEY;
  if (!apiKey) return { gold: [], oil: [] };

  try {
    const [gold, oil] = await Promise.all([
      fetchTimeSeries('XAU/USD', apiKey),
      fetchTimeSeries('WTI/USD', apiKey),
    ]);
    return { gold, oil };
  } catch {
    return { gold: [], oil: [] };
  }
}
