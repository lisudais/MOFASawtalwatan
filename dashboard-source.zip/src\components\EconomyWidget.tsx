import { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
import CollapsibleSection from './CollapsibleSection';
import AiInsightPanel from './AiInsightPanel';
import MiniLineChart from './charts/MiniLineChart';
import { fetchCommodityPrices, fetchCommodityTrends } from '../services/commodities';
import { CHART_SERIES_COLORS } from '../constants';
import type { CommodityQuote, PricePoint } from '../types';

const HAS_KEY = Boolean(import.meta.env.VITE_TWELVEDATA_API_KEY);

export default function EconomyWidget() {
  const [quotes, setQuotes] = useState<CommodityQuote[]>([]);
  const [trends, setTrends] = useState<{ gold: PricePoint[]; oil: PricePoint[] }>({ gold: [], oil: [] });

  useEffect(() => {
    if (!HAS_KEY) return;
    let cancelled = false;
    async function load() {
      const [quoteData, trendData] = await Promise.all([fetchCommodityPrices(), fetchCommodityTrends()]);
      if (!cancelled) {
        setQuotes(quoteData);
        setTrends(trendData);
      }
    }
    load();
    const interval = setInterval(load, 5 * 60 * 1000);
    return () => { cancelled = true; clearInterval(interval); };
  }, []);

  const buildSummary = () => {
    const prices = quotes.map((q) => `${q.nameAr} (${q.nameEn}): ${q.price} ${q.currency} (${q.changePercent >= 0 ? '+' : ''}${q.changePercent.toFixed(2)}%)`).join('، ');
    return `أسعار السلع الحالية: ${prices}`;
  };

  const chartSeries = [
    trends.gold.length > 0 && { name: 'Gold', color: CHART_SERIES_COLORS.gold, points: trends.gold.map((p) => ({ x: p.date.getTime(), y: p.value })) },
    trends.oil.length > 0 && { name: 'Oil (WTI)', color: CHART_SERIES_COLORS.oil, points: trends.oil.map((p) => ({ x: p.date.getTime(), y: p.value })) },
  ].filter(Boolean) as { name: string; color: string; points: { x: number; y: number }[] }[];

  return (
    <CollapsibleSection
      icon={<DollarSign size={14} />}
      titleEn="Economic Watch"
      titleAr="الرصد الاقتصادي"
      badge={<span className="panel-badge">{quotes.length}</span>}
    >
      {!HAS_KEY ? (
        <div className="widget-empty-state">
          أضف مفتاح Twelve Data API في ملف <code>.env</code> (متغير <code>VITE_TWELVEDATA_API_KEY</code>) لعرض أسعار الذهب والنفط مباشرة.
        </div>
      ) : quotes.length === 0 ? (
        <div className="widget-empty-state">جارِ تحميل الأسعار…</div>
      ) : (
        <>
          <div className="commodity-grid">
            {quotes.map((q) => {
              const up = q.changePercent >= 0;
              return (
                <div className="commodity-tile" key={q.symbol}>
                  <div className="commodity-name">
                    <span>{q.nameEn}</span>
                    <span className="commodity-name-ar">{q.nameAr}</span>
                  </div>
                  <div className="commodity-price">{q.price.toLocaleString(undefined, { maximumFractionDigits: 2 })} <span className="commodity-currency">{q.currency}</span></div>
                  <div className={`commodity-change ${up ? 'up' : 'down'}`}>
                    {up ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
                    {q.changePercent.toFixed(2)}%
                  </div>
                </div>
              );
            })}
          </div>
          {chartSeries.length > 0 && <MiniLineChart series={chartSeries} unit=" USD" />}
        </>
      )}

      <AiInsightPanel
        domainLabel="الاقتصاد (الذهب والنفط)"
        buildSummary={buildSummary}
        sourceNames={['Twelve Data']}
      />
    </CollapsibleSection>
  );
}
