import { AlertTriangle, Globe, Users, Bell, Activity, Zap } from 'lucide-react';
import type { DashboardStats } from '../types';

interface StatsBarProps {
  stats: DashboardStats;
}

export default function StatsBar({ stats }: StatsBarProps) {
  const items = [
    { icon: Activity, labelEn: 'Active Events',      labelAr: 'أحداث نشطة',       value: stats.totalEvents,        color: 'var(--saudi-gold)',      glow: false },
    { icon: Zap,      labelEn: 'Critical Alerts',    labelAr: 'تنبيهات حرجة',      value: stats.criticalEvents,     color: 'var(--danger-critical)', glow: stats.criticalEvents > 0 },
    { icon: Globe,    labelEn: 'Countries Affected',  labelAr: 'دول متأثرة',         value: stats.affectedCountries,  color: 'var(--danger-high)',     glow: false },
    { icon: Users,    labelEn: 'Travelers at Risk',   labelAr: 'مسافرون في خطر',     value: stats.travelersAtRisk,    color: 'var(--danger-medium)',   glow: false },
    { icon: Bell,     labelEn: 'Notifications Sent',  labelAr: 'إشعارات مُرسلة',     value: stats.notificationsSent,  color: 'var(--saudi-light)',     glow: false },
    { icon: AlertTriangle, labelEn: 'Active Alerts',  labelAr: 'تنبيهات فعّالة',     value: stats.activeAlerts,       color: 'var(--danger-high)',     glow: false },
  ];

  return (
    <div className="stats-bar">
      {items.map(({ icon: Icon, labelEn, labelAr, value, color, glow }) => (
        <div className={`stat-card${glow ? ' stat-card-critical' : ''}`} key={labelEn}>
          <div className="stat-icon" style={{ color, borderColor: color + '33', background: color + '12' }}>
            <Icon size={16} />
          </div>
          <div className="stat-body">
            <span className="stat-value" style={{ color }}>{value.toLocaleString()}</span>
            <span className="stat-label-en">{labelEn}</span>
            <span className="stat-label-ar">{labelAr}</span>
          </div>
        </div>
      ))}
    </div>
  );
}
