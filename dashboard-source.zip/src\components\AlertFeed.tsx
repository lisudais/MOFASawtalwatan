import { useState, useEffect, useRef } from 'react';
import type { GeoEvent, RiskLevel } from '../types';
import { RISK_COLORS, TYPE_ICON } from '../constants';
import { AlertTriangle, Zap, Activity, Clock, MapPin } from 'lucide-react';

interface AlertFeedProps {
  events: GeoEvent[];
  selectedEvent: GeoEvent | null;
  onSelectEvent: (e: GeoEvent) => void;
}

function timeAgo(date: Date): string {
  const diff = Date.now() - date.getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

const PRIORITY: Record<RiskLevel, number> = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3, SAFE: 4 };

// How long the "new" state persists (ms) — entrance + glow duration
const NEW_BADGE_TTL = 4000;

export default function AlertFeed({ events, selectedEvent, onSelectEvent }: AlertFeedProps) {
  const prevIdsRef = useRef<Set<string> | null>(null);
  const [newIds, setNewIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    const currentIds = new Set(events.map((e) => e.id));

    if (prevIdsRef.current === null) {
      // Initial load — record IDs silently, no entrance animation
      prevIdsRef.current = currentIds;
      return;
    }

    const added = events.filter((e) => !prevIdsRef.current!.has(e.id));
    prevIdsRef.current = currentIds;

    if (added.length === 0) return;

    const addedIds = new Set(added.map((e) => e.id));
    setNewIds((prev) => new Set([...prev, ...addedIds]));

    const timer = setTimeout(() => {
      setNewIds((prev) => {
        const next = new Set(prev);
        addedIds.forEach((id) => next.delete(id));
        return next;
      });
    }, NEW_BADGE_TTL);

    return () => clearTimeout(timer);
  }, [events]);

  const sorted = [...events].sort(
    (a, b) => PRIORITY[a.riskLevel] - PRIORITY[b.riskLevel] || b.timestamp.getTime() - a.timestamp.getTime()
  );

  return (
    <div className="panel alert-feed">
      <div className="panel-header">
        <Activity size={14} />
        <span>Global Alert Feed</span>
        <span className="panel-header-ar">تغذية التنبيهات</span>
        <span className="panel-badge">{events.length}</span>
      </div>
      <div className="feed-list">
        {sorted.map((event) => {
          const color = RISK_COLORS[event.riskLevel];
          const isSelected = selectedEvent?.id === event.id;
          const isNew = newIds.has(event.id);
          const Icon = TYPE_ICON[event.type] ?? AlertTriangle;
          return (
            <div
              key={event.id}
              className={`feed-item${isSelected ? ' selected' : ''}${isNew ? ' feed-item-new' : ''}`}
              style={{ borderLeftColor: color }}
              onClick={() => onSelectEvent(event)}
            >
              <div className="feed-icon-wrap" style={{ color }}>
                <Icon size={16} />
              </div>
              <div className="feed-body">
                <div className="feed-title">{event.title}</div>
                <div className="feed-meta">
                  <span className="feed-country">
                    <MapPin size={9} /> {event.country}
                  </span>
                  <span className="feed-source">{event.source}</span>
                  <span className="feed-time">
                    <Clock size={9} />
                    {timeAgo(event.timestamp)}
                  </span>
                </div>
                <div className="feed-score-row">
                  <span className="risk-badge" style={{ background: color + '22', color, border: `1px solid ${color}` }}>
                    {event.riskLevel === 'CRITICAL' && <Zap size={9} />}
                    {event.riskLevel}
                  </span>
                  <div className="score-bar">
                    <div className="score-fill" style={{ width: `${event.score}%`, background: color }} />
                  </div>
                  <span className="score-num" style={{ color }}>{event.score}</span>
                  {isNew && <span className="feed-new-badge">جديد</span>}
                </div>
              </div>
              {event.riskLevel === 'CRITICAL' && (
                <div className="critical-indicator">
                  <AlertTriangle size={14} color="#FF1744" />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
